package com.example.android.travelmantics;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class FireUtil {
    public static FirebaseDatabase mFirebaseDatabase;
    public static DatabaseReference mDatabaseReference;
    private static FireUtil FireUtil;
    public static ArrayList<TravelDeals> mDeals;

    private FireUtil() {};

    public static void openFbReference(String ref) {
        if(FireUtil == null) {
            FireUtil = new FireUtil();
            mFirebaseDatabase = FirebaseDatabase.getInstance();
            mDeals = new ArrayList<TravelDeals>();
        }
        mDatabaseReference = mFirebaseDatabase.getReference().child(ref);

    }


}
